from django.contrib import admin

# Register your models here.

from django.contrib import admin
from .models import *
# Register your models here.


class InvoiceA(admin.ModelAdmin):
    list_display = [field.name for field in Invoice._meta.get_fields()]


class InvestorA(admin.ModelAdmin):
    list_display = [field.name for field in Investor._meta.get_fields()]


class BusinessA(admin.ModelAdmin):
    list_display = [field.name for field in Business._meta.get_fields()]


class TransactionA(admin.ModelAdmin):
    list_display = [field.name for field in Transaction._meta.get_fields()]


class EntityA(admin.ModelAdmin):
    list_display = [field.name for field in Entity._meta.get_fields()]


class RateOfInterestA(admin.ModelAdmin):
    list_display = [field.name for field in EntityBusinessROIMapping._meta.get_fields()]


class RateOfReturnA(admin.ModelAdmin):
    list_display = [field.name for field in EntityInvestorRORMapping._meta.get_fields()]


class UserTypeA(admin.ModelAdmin):
    list_display = [field.name for field in UserType._meta.get_fields()]


class InvoiceAdmin(admin.ModelAdmin):
    formfield_overrides = {
        models.DateTimeField: {'input_formats': ('%d/%m/%Y',)},
    }


admin.site.register(Investor, InvestorA)
admin.site.register(Invoice, InvoiceA)
admin.site.register(Business, BusinessA)
admin.site.register(Transaction, TransactionA)
admin.site.register(Entity, EntityA)
admin.site.register(EntityBusinessROIMapping, RateOfInterestA)
admin.site.register(EntityInvestorRORMapping, RateOfReturnA)
admin.site.register(UserType, UserTypeA)
