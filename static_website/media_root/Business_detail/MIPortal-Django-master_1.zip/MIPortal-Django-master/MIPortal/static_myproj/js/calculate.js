//function calculation() {
//    var amount = document.getElementById("amount").value;
//    var ind_yield = {{yield}}
//    console.log(a);
//}
//var amount = document.getElementById("amount").value;
//var ind_yield = {{yield}}
//console.log(a);