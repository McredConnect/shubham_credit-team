from django.shortcuts import render

# Create your views here.


def bank_detail(request):
    return render(request, 'InvestorDashboards/bankdetail.html')


def business_detail(request):
    return render(request, 'InvestorDashboards/businessdetail.html')


def business(request):
    return render(request, 'InvestorDashboards/business.html')


def business_info(request):
    return render(request, 'InvestorDashboards/businessinfo.html')


def bank_statement(request):
    return render(request, 'InvestorDashboards/bankstatement.html')


def company_details(request):
    return render(request, 'InvestorDashboards/companydetails.html')


def gst_details(request):
    return render(request, 'InvestorDashboards/gstdetails.html')


def pan_details(request):
    return render(request, 'InvestorDashboards/pandetails.html')


