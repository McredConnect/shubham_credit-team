from django.apps import AppConfig


class InvestordashboardsConfig(AppConfig):
    name = 'InvestorDashboards'
