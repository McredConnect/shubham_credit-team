from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('bank_details', views.bank_detail, name='bank_details'),
    path('business_detail', views.business_detail, name='business_detail'),
    path('business', views.business, name='business'),
    path('business_info', views.business_info, name='business_info'),
    path('bank_statement', views.bank_statement, name='bank_statement'),
    path('company_details', views.company_details, name='company_details'),
    path('gst_details', views.gst_details, name='gst_details'),
    path('pan_details', views.pan_details, name='pan_details'),
]
