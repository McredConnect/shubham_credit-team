var mileStones = Array.from(document.querySelectorAll('.primary-color'));
mileStones.forEach(elem => {
  elem.onclick = function() {
    const current = this;
    let flag = false;
    document.getElementById('pp').style.width = current.dataset.width+'%';
    mileStones.forEach(elem =>{
      elem.classList.add('active');

      if(flag) elem.classList.remove('active');
      if(current.id === elem.id) flag = true;

    });
  }
});