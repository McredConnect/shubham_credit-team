from django.shortcuts import render

# Create your views here.


def support(request):
    return render(request, 'investors/help2.html')

def orders(request):
    return render(request,'investors/order2.html')

def transaction(request):
    return render(request,'investors/transaction.html')

def currentdeals(request):
    return render(request,'investors/currentdeals2a.html')

def managefunds(request):
    return render(request,'investors/managefunds2.html')

def demo(request):
    return render(request,'investors/demo.html')

def addfunds(request):
    return render(request,'investors/addfunds2.html')

def withdrawal(request):
    return render(request,'investors/withdrawal2.html')