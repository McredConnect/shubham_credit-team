from django.urls import path, include
from . import views

urlpatterns = [
    path('', views.support, name='help'),
    path('order/', views.orders, name='order'),
    path('transaction/',views.transaction, name='transaction'),
    path('currentdeals/',views.currentdeals, name='currentdeals'),
    path('managefunds/',views.managefunds, name='managefunds'),
    path('demo/',views.demo, name='demo'),
    path('addfunds/',views.addfunds, name='addfunds'),
    path('withdrawal/',views.withdrawal, name='withdrawal'),


]
